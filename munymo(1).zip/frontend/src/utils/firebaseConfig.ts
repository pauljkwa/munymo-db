// ui/src/utils/firebaseConfig.ts

export const firebaseConfig = {
  apiKey: "AIzaSyD4Z130kgtqBcYJORztSULeE1Vbflrds", // Fixed malformed API key for production
  authDomain: "munymo-db.firebaseapp.com",
  projectId: "munymo-db",
  storageBucket: "munymo-db.appspot.com",
  messagingSenderId: "828532471679",
  appId: "1:828532471679:web:4adb1e08e362ed97d70c4a",
  measurementId: "G-V01VKFVLC8",
  vapidKey: "BKeRSxIwdaYtj8wTnzw2iZcSdSHgTs-z2fwTCSvF27SFA2prUV7wh2uRTfsJ-UXOUcuDWKyPClO9YizLJvZhXJc",
};
