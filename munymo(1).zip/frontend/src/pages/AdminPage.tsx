import React from 'react';
import { AdminPanel } from "components/AdminPanel";

function AdminPage() {
  return <AdminPanel />;
}

export default AdminPage;
